/* message */

const form = document.querySelector("#myForm");

form.addEventListener("submit", () => {
  alert("Your message has been sent successfully!");
});
